class Search < ApplicationRecord
end
